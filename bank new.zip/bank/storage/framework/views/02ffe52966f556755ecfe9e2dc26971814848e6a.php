<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo e(asset('app/style.css')); ?>" rel="stylesheet" type="text/css">

    <title>Hello, world!</title>
    <style>
        html,
        body {
            width: 100%;
            height: 100%;
            background: url(https://subtlepatterns.com/patterns/sativa.png) repeat fixed;
            font-family: 'Open Sans', sans-serif;
            font-weight: 200;
        }
    </style>
  </head>
  <body>
    <form class="login" method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
    <?php echo csrf_field(); ?>
        <fieldset>
            
            <legend class="legend">Login</legend>

            <div class="input">
                <input type="email" placeholder="Email"  class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus  />
            <div class="span"><i class="fa fa-envelope-o"></i></div>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
            
            <div class="input">
                <input type="password" placeholder="Password" class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required />
            <div class="span"><i class="fa fa-lock"></i></div>
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
            </div>
            
            <button type="submit" class="submit"><i class="fa fa-long-arrow-right"></i></button>
            
        </fieldset>
        
        <div class="feedback">
            login successful <br />
            redirecting...
        </div>
        
    </form>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('app/main.js')); ?>" ></script>

  </body>
</html>