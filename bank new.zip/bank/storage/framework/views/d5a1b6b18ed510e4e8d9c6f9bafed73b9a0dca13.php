<?php $__env->startSection('content'); ?>
<style>
    body{
        direction: rtl;
        text-align: right;
    }
    .card-header {
        position: relative;
    }
    .plus
    {
        position: absolute;
        left: 0;
        top: 0px;
        margin: 10px;
        color: #fff;
        font-size: 10px;
    }
    .bg-info {
        background-color: #27ae60!important;
    }
    .card-body{
        padding: 0;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card">
                
                <div class="card-header bg-info text-white"><?php echo app('translator')->getFromJson("site.users"); ?>
                    <a href="<?php echo e(url()->previous()); ?>" class="plus btn btn-dark btn-sm"> <?php echo app('translator')->getFromJson("site.perv"); ?> <i class="fa fa-arrow-left"></i></a>
                </div>
                
                <div class="card-body">
                    <form method="POST" action="<?php echo e(Route('users.store')); ?>" style="padding: 15px;">
                        <?php echo csrf_field(); ?>
                        

                         
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label"><?php echo app('translator')->getFromJson("site.username"); ?> :</label>
                            <input type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" required value="<?php echo e(old("name")); ?>">
                            <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                           
                        </div>
    
                        
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label"><?php echo app('translator')->getFromJson("site.email"); ?>:</label>
                            <input type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" required value="<?php echo e(old("email")); ?>">
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                           
                        </div>
    
                        
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label"><?php echo app('translator')->getFromJson("site.password"); ?>:</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
    
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label"><?php echo app('translator')->getFromJson("site.role"); ?>:</label>
                            <select class=" edituser" style="width: 100%" name="role" required>
                                <option value="0" <?php echo e(old("role") == 1 ? "selected":""); ?>><?php echo app('translator')->getFromJson("site.client"); ?></option>
                                <option value="1" <?php echo e(old("role") == 1 ? "selected" : ""); ?>><?php echo app('translator')->getFromJson("site.admin"); ?></option>
                                <option value="2" <?php echo e(old("role") == 2 ? "selected" : ""); ?>><?php echo app('translator')->getFromJson("site.emp"); ?></option>

                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->getFromJson('site.save'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

      

<?php $__env->stopSection(); ?>


<?php echo $__env->make('../layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>