<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo e(asset('app/style.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('app/select2.min.css')); ?>" rel="stylesheet" type="text/css">    
    <link href="<?php echo e(asset('app/select2.full.min.js')); ?>" rel="stylesheet" type="text/css"> 
    <style>
      label.btn span {
        font-size: 1.5em ;
      }

      label input[type="radio"] ~ i.fa.fa-circle-o{
          color: #c8c8c8;    display: inline;
      }
      label input[type="radio"] ~ i.fa.fa-dot-circle-o{
          display: none;
      }
      label input[type="radio"]:checked ~ i.fa.fa-circle-o{
          display: none;
      }
      label input[type="radio"]:checked ~ i.fa.fa-dot-circle-o{
          color: #7AA3CC;    display: inline;
      }
      label:hover input[type="radio"] ~ i.fa {
      color: #7AA3CC;
      }

      label input[type="checkbox"] ~ i.fa.fa-square-o{
          color: #c8c8c8;    display: inline;
      }
      label input[type="checkbox"] ~ i.fa.fa-check-square-o{
          display: none;
      }
      label input[type="checkbox"]:checked ~ i.fa.fa-square-o{
          display: none;
      }
      label input[type="checkbox"]:checked ~ i.fa.fa-check-square-o{
          color: #7AA3CC;    display: inline;
      }
      label:hover input[type="checkbox"] ~ i.fa {
      color: #7AA3CC;
      }

      div[data-toggle="buttons"] label.active{
          color: #7AA3CC;
      }

      div[data-toggle="buttons"] label {
        display: inline-block;
        padding: 6px 12px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 2em;
        text-align: left;
        white-space: nowrap;
        vertical-align: top;
        cursor: pointer;
        background-color: none;
        border: 0px solid 
        #c8c8c8;
        border-radius: 3px;
        color: #c8c8c8;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        -o-user-select: none;
        user-select: none;
      }

      div[data-toggle="buttons"] label:hover {
        color: #7AA3CC;
      }

      div[data-toggle="buttons"] label:active, div[data-toggle="buttons"] label.active {
        -webkit-box-shadow: none;
        box-shadow: none;
      }
    </style>
    <title>Hello, world!</title>
  </head>
  <body>

        <!-- multistep form -->
        <form id="msform" action="<?php echo e(url("addrequest")); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <!-- progressbar -->
          <ul id="progressbar" class="">
              <li class="active"><?php echo app('translator')->getFromJson('site.create'); ?></li>
              <li><?php echo app('translator')->getFromJson('site.chose brunch'); ?></li>
              
          </ul>
          <!-- fieldsets -->
          <fieldset>
              <h2 class="fs-title"><?php echo app('translator')->getFromJson('site.create'); ?></h2>
              

              <div class="row">
                <div class="col-xs-12 " >
                  <div class="btn-group btn-group-vertical d-flex justify-content-center" data-toggle="buttons">
                    <label class="btn active">
                      <input class="d-none" type="radio" name='role' value="0" checked ><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i> <span> <?php echo app('translator')->getFromJson('site.terller'); ?></span>
                    </label>
                    <label class="btn">
                      <input class="d-none" type="radio" name='role' value="1"><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i><span> <?php echo app('translator')->getFromJson('site.service'); ?></span>
                    </label>
                  </div>

                </div>
              </div>
              <input type="button" name="next" class="next action-button" value="<?php echo app('translator')->getFromJson('site.sure'); ?>" />
          </fieldset>
          <fieldset>
              <h2 class="fs-title"><?php echo app('translator')->getFromJson('site.chose brunch'); ?></h2>
              
              <div class="form-group">
                <?php if(count($branches) > 0): ?>
                <select class="branches" style="width: 100%" name="Branche" required>
                  <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branche): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($branche->id); ?>"><?php echo e($branche->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php endif; ?>
            </div>
              <input type="button" name="previous" class="previous action-button" value="<?php echo app('translator')->getFromJson('site.back'); ?>" />
              <button type="submit" class="submit action-button w-100"><?php echo app('translator')->getFromJson('site.sure'); ?></button>
          </fieldset>
      </form>
        
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('app/select2.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('app/main.js')); ?>" ></script>
    <script>
      $(function () {
        'use strict';
        $('.branches').select2();
      });
    </script>
  </body>
</html>

