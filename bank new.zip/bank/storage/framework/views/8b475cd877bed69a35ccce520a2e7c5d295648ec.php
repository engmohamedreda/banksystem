<?php $__env->startSection('content'); ?>
<style>
    body{
        direction: rtl;
        text-align: right;
    }
    .card-header {
        position: relative;
    }
    .plus
    {
        position: absolute;
        left: 0;
        top: 0px;
        margin: 10px;
        color: #fff;
        font-size: 10px;
    }
    .bg-info {
        background-color: #27ae60!important;
    }
    .card-body{
        padding: 0;
    }
    .table {
        margin-bottom: 0;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
                <div class="card-header bg-info text-white"><?php echo app('translator')->getFromJson("site.braunch"); ?>
                    <a href="<?php echo e(route("branches.create")); ?>"class="plus btn btn-dark btn-sm" >
                            <i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson("site.add"); ?>
                        </a>
                </div>
                
                <div class="card-body">
                    <div class="">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    <table class="table table-responsive-xs table-bordered text-center">
                        <thead>
                            <tr class="" style="font-size: 10px;">
                                <th><?php echo app('translator')->getFromJson("site.id"); ?></th>
                                <th><?php echo app('translator')->getFromJson("site.address"); ?></th> 
                                <th><?php echo app('translator')->getFromJson("site.time"); ?></th>
                            </tr> 
                        </thead> 
                        <tbody>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branche): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="font-size: 10px;">
                                <th scope="row"><?php echo e($branche->id); ?></th>
                                <td><?php echo e($branche->name); ?></td>
                                <td><?php echo $branche->end_date; ?> | <?php echo $branche->start_date; ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>