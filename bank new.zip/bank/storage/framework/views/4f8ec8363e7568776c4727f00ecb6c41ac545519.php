<?php $__env->startSection('content'); ?>
<style>
    body{
        direction: rtl;
        text-align: right;
    }
    .card-header {
        position: relative;
    }
    .plus
    {
        position: absolute;
        left: 0;
        top: 0px;
        margin: 10px;
        color: #fff;
        font-size: 10px;
    }
    .bg-info {
        background-color: #27ae60!important;
    }
    .card-body{
        padding: 0;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card">
                
                
                <div class="card-header bg-info text-white"><?php echo app('translator')->getFromJson("site.client"); ?>
                    <a href="<?php echo e(url("delempoloye")); ?>" class="plus btn btn-danger btn-sm"> <?php echo app('translator')->getFromJson("site.neworder"); ?> <i class="fa fa-trash"></i></a>
                </div>
                
                <div class="card-body">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"><?php echo app('translator')->getFromJson("site.service"); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false"><?php echo app('translator')->getFromJson("site.terller"); ?></a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <table class="table table-responsive-xs table-bordered text-center">
                                    <thead>
                                        <tr class="">
                                            <th><?php echo app('translator')->getFromJson("site.id"); ?></th>
                                            <th><?php echo app('translator')->getFromJson("site.name"); ?></th> 
                                            <th><?php echo app('translator')->getFromJson("site.name braunch"); ?></th> 
                                            <th><?php echo app('translator')->getFromJson("site.time"); ?></th>
                                        </tr> 
                                    </thead> 
                                    <tbody>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($service->id); ?></th>
                                            <td><?php echo e($service->order->user->name); ?></td>
                                            <td><?php echo e($service->order->user->branche->name); ?></td>
                                            <td><?php echo e($service->data_come); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                    <table class="table table-responsive-xs table-bordered text-center">
                                        <thead>
                                            <tr class="">
                                                <th><?php echo app('translator')->getFromJson("site.id"); ?></th>
                                                <th><?php echo app('translator')->getFromJson("site.name"); ?></th> 
                                                <th><?php echo app('translator')->getFromJson("site.name braunch"); ?></th> 
                                                <th><?php echo app('translator')->getFromJson("site.time"); ?></th>
                                            </tr> 
                                        </thead> 
                                        <tbody>
                                            <?php $__currentLoopData = $terllers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($service->id); ?></th>
                                                <td><?php echo e($service->order->user->name); ?></td>
                                                <td><?php echo e($service->order->user->branche->name); ?></td>
                                                <td><?php echo e($service->data_come); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

      

<?php $__env->stopSection(); ?>


<?php echo $__env->make('../layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>