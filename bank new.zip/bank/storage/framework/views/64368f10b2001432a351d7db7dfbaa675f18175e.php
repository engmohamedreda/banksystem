<?php $__env->startSection('content'); ?>
<style>
    body{
        direction: rtl;
        text-align: right;
    }
    .card-header {
        position: relative;
    }
    .plus
    {
        position: absolute;
        left: 0;
        top: 0px;
        margin: 10px;
        color: #fff;
        font-size: 10px;
    }
    .bg-info {
        background-color: #27ae60!important;
    }
    .card-body{
        padding: 0;
    }
    .table {
        margin-bottom: 0;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
                <div class="card-header bg-info text-white"><?php echo app('translator')->getFromJson("site.users"); ?>
                    <a href="<?php echo e(route("users.create")); ?>"class="plus btn btn-dark btn-sm" >
                            <i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson("site.add"); ?>
                        </a>
                </div>
                
                <div class="card-body">
                    <div class="">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    <table class="table table-responsive-xs table-bordered text-center">
                        <thead>
                            <tr class="">
                                <th><?php echo app('translator')->getFromJson("site.id"); ?></th>
                                <th><?php echo app('translator')->getFromJson("site.name"); ?></th> 
                                <th><?php echo app('translator')->getFromJson("site.stutas"); ?></th> 
                                <th><?php echo app('translator')->getFromJson("site.options"); ?></th>
                            </tr> 
                        </thead> 
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($user->id); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td>
                                    <?php if($user->role == 1 ): ?>
                                    <span class="badge badge-pill badge-primary text-white"><?php echo app('translator')->getFromJson("site.admin"); ?></span>
                                    <?php elseif($user->role == 2 ): ?>
                                    <span class="badge badge-pill badge-danger text-white"><?php echo app('translator')->getFromJson("site.emp"); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge-pill badge-dark text-white"><?php echo app('translator')->getFromJson("site.client"); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="option">
                                        <a class="badge badge-success text-white" href="<?php echo e(Route("users.edit" ,$user->id  )); ?>"><i class="fa fa-edit"></i></a>                                    
                                        <form style="display: inline" action="<?php echo e(Route('users.destroy' , $user->id)); ?>" method="POST" >
                                            <?php echo csrf_field(); ?>
                                            <input name="_method" type="hidden" value="DELETE">
                                            <button type="submit" style=" border: none;" class="badge badge-danger text-white" onclick="return confirm('Are you sure you want to delete this item?');">
                                                <i class="fa fa-trash"></i>
                                            </button>                                            
                                        </form>
                                    </div>
                                   
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>