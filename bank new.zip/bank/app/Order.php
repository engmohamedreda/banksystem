<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function terller()
    {
        return $this->hasMany(terller::class);
    }

    public function service()
    {
        return $this->hasOne(CustomerService::class);
    }
    public function branche()
    {
        return $this->belongsTo(Branche::class);
    }

    
}
