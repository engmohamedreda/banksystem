<?php

namespace App\Http\Controllers;

use App\Order;
use App\user;
use App\Branche;
use App\terller;
use App\CustomerService;
use Auth;
use Illuminate\Http\Request;

class OrdersController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    public function index()
    {
        //
    }


    public function create()
    {
        //
    }

    public function store(Request $request)
    {   

        $branche_id  = Branche::find($request->Branche);

        $id = Auth::user()->id;

        $order = User::find($id)->order()->get();
        // dd($order);
        if ($request->role == 1 ) {
            $service = CustomerService::get();
            $service_id_data = CustomerService::latest()->first();
            // service +15
            $addtime = '+15 minutes';
            if (! empty($service) && count($service) > 0) {
            // dd($service);
                $strtotime = strtotime($service_id_data->data_come);
            } else {
                $strtotime = strtotime($branche_id->start_date);                
            }

        } else {
            $terller = terller::get();
            $terlle_id_date = terller::latest()->first();
            $addtime = '+5 minutes';
            if (!empty($terller) && count($terller) ) {
                $strtotime = strtotime($terlle_id_date->data_come);
            } else {
                $strtotime = strtotime($branche_id->start_date);                
            }
            // teller +5 
        }
        $date = date('H:i:s',strtotime($addtime,$strtotime));
        
        if (count ($order) >= 2 ) { 
            return redirect('show_number');
        } else {



            if ($request->role == 1) { 
                $user = new Order;
                $user->role       = $request->role;
                $user->user_id      = Auth::user()->id;
                $user->branche_id      = $request->Branche;
                $user->save();
    
                //get last 
                $order_id = Order::latest()->first()->id;

                $getdate = Order::join('customer_services', 'orders.id', '=', 'customer_services.order_id')
                ->where([['orders.id' , $order_id ],['orders.user_id' , $id]])
                ->first();
                // dd($getdate);
                if ($getdate == null) {
                    $come = CustomerService::latest()->first();
                    $user = new CustomerService;
                    $user->order_id      = $order_id;
                    $user->data_come      = $date;
                    $user->save();
                } else {
                    return redirect('show_number');
                }

            } else {
                $user = new Order;
                $user->role       = $request->role;
                $user->user_id      = Auth::user()->id;
                $user->branche_id      = $request->Branche;
                $user->save();
    
                //get last 
                $order_id = Order::latest()->first()->id;
                $getdate = Order::join('terllers', 'orders.id', '=', 'terllers.order_id')
                ->where(['orders.id' => $order_id  ,'orders.user_id' => $id])
                ->first();
                if ($getdate == null) {
                    $come = terller::latest()->first();
                    $user = new terller;
                    $user->order_id      = $order_id;
                    $user->data_come      = $date;
                    $user->save();
                } else {
                    return redirect('show_number');
                }
            }
        }
         
        return redirect('show_number');
        
    }


    public function show(Request $orders)
    {
        // dd($getdate);
        $customer = Order::join('customer_services', 'orders.id', '=', 'customer_services.order_id')
        ->join('branches', 'orders.branche_id', '=', 'branches.id')->select("customer_services.id", "customer_services.data_come" , "branches.lat" ,"branches.long")->where('orders.user_id' , Auth::user()->id)->first();

        $terller = Order::join('terllers', 'orders.id', '=', 'terllers.order_id')
        ->join('branches', 'orders.branche_id', '=', 'branches.id')->select("terllers.id", "terllers.data_come" , "branches.lat" ,"branches.long")->where('orders.user_id' , Auth::user()->id)->first();
        // dd($terller);
        return view("app.profile" ,compact ("customer" , "terller"));
    }

    public function edit(Request $orders)
    {
        //
    }


    public function update(Request $request, Orders $orders)
    {
        //
    }


    public function destroy(Request $orders)
    {
        terller::query()->truncate();
        CustomerService::query()->truncate();
        Order::query()->truncate();
        return back();
    }
}
