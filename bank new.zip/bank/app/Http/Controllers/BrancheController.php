<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Branche;
use App\User;
use Validator;
use Session;

class BrancheController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    public function index()
    {
        $branches = Branche::get();
        return view('braunch.index', compact('branches'));
    }

    public function create()
    {
        return view('braunch.add');        
    }


    public function store(Request $request)
    {

        $user = new Branche;
        $user->name       = $request->name;
        $user->phone      = $request->phone;
        $user->start_date      = $request->start;
        $user->end_date      = $request->end;
        $user->address   = $request->address;
        $user->lat       = $request->lat;
        $user->long       = $request->long;
        $user->save();
        return redirect()->route("branches.index")->with("status", "Your message has been received, We'll get back to you shortly.");

    }

    public function show(Request $branche)
    {
        //
    }


    public function edit(Request $branche)
    {
        $user = Branche::where('id', $id)->first();
        return view("braunch.edit", compact("user"));
    }


    public function update(Request $request, Branche $branche)
    {
        
        $validator = Validator::make($request->all(), [
            'email' => "required|email|unique:users,email,$id",
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $user = User::find($id);
        $user->name       = $request->name;
        $user->email      = $request->email;
        $user->role       = $request->role;
        if (! empty($request->newpassword) ) {
            $user->password   = bcrypt($request->newpassword);
        } else {
            $user->password = $request->oldpassword;          
        }
        $user->save();
        return redirect()->route("braunch.index");
    }

    public function destroy(Request $branche)
    {
        $id = User::find($id);
        $id->delete();
        return back();
    }
}
