<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Session;
use App\Order;
use App\user;
use App\Branche;
use App\terller;
use App\CustomerService;
use Auth;


class AppController extends Controller
{


    public function request(Request $request)
    {
        $branches = Branche::get();
        return view('app.page', compact('branches'));        
    }

    public function addrequest(Request $request)
    {
        dd($request->all());
        // $branches = Branche::get();
        // return view('app.page', compact('branches'));        
    }


    public function index()
    {
        $users = User::get();
        return view('users.index', compact('users'));
    }

    public function create()
    {
        $branches = Branche::get();
        return view('users.addusers', compact('branches'));
        
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|unique:users',
            'name' => 'required|string|max:50',
            'password' => 'required',
            'role' => 'required'
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }
        $user = new User;
        $user->name       = $request->name;
        $user->email      = $request->email;
        $user->password   = bcrypt($request->password);
        $user->role       = $request->role;
        $user->branche_id       = $request->Branche;
        $user->save();
        return redirect()->route("users.index")->with("status", "Your message has been received, We'll get back to you shortly.");

    }


    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        $user = User::where('id', $id)->first();
        return view("users.editusers", compact("user"));
    }


    public function update(Request $request, $id)
    {

        $validator = Validator::make($request->all(), [
            'email' => "required|email|unique:users,email,$id",
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $user = User::find($id);
        $user->name       = $request->name;
        $user->email      = $request->email;
        $user->role       = $request->role;
        if (! empty($request->newpassword) ) {
            $user->password   = bcrypt($request->newpassword);
        } else {
            $user->password = $request->oldpassword;          
        }
        $user->save();
        return redirect()->route("users.index");

    }

    
    public function empoloye()
    {

         $terllers = terller::get();
         $services = CustomerService::get();
        return view("profile" , compact("services" , "terllers"));
    }

    public function destroy($id)
    {
        $id = User::find($id);
        $id->delete();
        return back();
    }

}
