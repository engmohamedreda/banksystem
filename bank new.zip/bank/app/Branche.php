<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Branche extends Model
{

    
    public function user()
    {
        return $this->hasMany(User::class);
    }
    public function order()
    {
        return $this->hasMany(Order::class);
    }
    
}
