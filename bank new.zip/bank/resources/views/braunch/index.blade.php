@extends('../layouts.app')

@section('content')
<style>
    body{
        direction: rtl;
        text-align: right;
    }
    .card-header {
        position: relative;
    }
    .plus
    {
        position: absolute;
        left: 0;
        top: 0px;
        margin: 10px;
        color: #fff;
        font-size: 10px;
    }
    .bg-info {
        background-color: #27ae60!important;
    }
    .card-body{
        padding: 0;
    }
    .table {
        margin-bottom: 0;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
                <div class="card-header bg-info text-white">@lang("site.braunch")
                    <a href="{{ route("branches.create") }}"class="plus btn btn-dark btn-sm" >
                            <i class="fa fa-plus"></i> @lang("site.add")
                        </a>
                </div>
                
                <div class="card-body">
                    <div class="">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                    <table class="table table-responsive-xs table-bordered text-center">
                        <thead>
                            <tr class="" style="font-size: 10px;">
                                <th>@lang("site.id")</th>
                                <th>@lang("site.address")</th> 
                                <th>@lang("site.time")</th>
                            </tr> 
                        </thead> 
                        <tbody>
                            @foreach ($branches as $branche)
                            <tr style="font-size: 10px;">
                                <th scope="row">{{ $branche->id }}</th>
                                <td>{{ $branche->name }}</td>
                                <td>{!! $branche->end_date !!} | {!!$branche->start_date !!}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

      
@endsection
