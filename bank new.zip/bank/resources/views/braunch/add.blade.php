@extends('../layouts.app')

@section('content')
<style>
    body{
        direction: rtl;
        text-align: right;
    }
    .card-header {
        position: relative;
    }
    .plus
    {
        position: absolute;
        left: 0;
        top: 0px;
        margin: 10px;
        color: #fff;
        font-size: 10px;
    }
    .bg-info {
        background-color: #27ae60!important;
    }
    .card-body{
        padding: 0;
    }
    #map {
  overflow: hidden;
  width: 100% !important;
  height: 500px !important;
  margin: 20px;
}
#description {
  font-family: Roboto;
  font-size: 15px;
  font-weight: 300;
}

#infowindow-content .title {
  font-weight: bold;
}

#infowindow-content {
  display: none;
}

#map #infowindow-content {
  display: inline;
}

.pac-card {
  margin: 10px 10px 0 0;
  border-radius: 2px 0 0 2px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  outline: none;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
  background-color: #fff;
  font-family: Roboto;
}

#pac-container {
  padding-bottom: 12px;
  margin-right: 12px;
}

.pac-controls {
  display: inline-block;
  padding: 5px 11px;
}

.pac-controls label {
  font-family: Roboto;
  font-size: 13px;
  font-weight: 300;
}

#pac-input {
  background-color: #fff;
  font-family: Roboto;
  font-size: 15px;
  font-weight: 300;
  margin-left: 12px;
  padding: 0 11px 0 13px;
  text-overflow: ellipsis;
  {{--  width: 400px;  --}}
}

#pac-input:focus {
  border-color: #4d90fe;
}

#title {
  color: #fff;
  background-color: #4d90fe;
  font-size: 25px;
  font-weight: 500;
  padding: 6px 12px;
}

</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card">
                {{--  <a href="{{ url()->previous() }}">111</a>  --}}
                <div class="card-header bg-info text-white">@lang("site.braunch")
                    <a href="{{ url()->previous() }}" class="plus btn btn-dark btn-sm"> @lang("site.perv") <i class="fa fa-arrow-left"></i></a>
                </div>
                
                <div class="card-body">
                    <form method="POST" action="{{ Route('branches.store')}}" style="padding: 15px;">
                        @csrf
                        {{--  {{ method_field('PATCH') }}  --}}

                        {{--  username  --}} 
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.name braunch") :</label>
                            <input type="text" class="form-control {{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" required value="{{ old("name") }}">
                            @if ($errors->has('name'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('name') }}</strong>
                                </span>
                            @endif
                           
                        </div>
    
                        {{--  phone  --}}
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.phone"):</label>
                            <input type="phone" class="form-control {{ $errors->has('phone') ? ' is-invalid' : '' }}" name="phone" required value="{{ old("phone") }}">
                            @if ($errors->has('phone'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('phone') }}</strong>
                                </span>
                            @endif
                           
                        </div>
    
                        {{--  start date   --}}
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.start"):</label>
                            <input type="time" class="form-control" name="start" min="9:00" max="18:00" value="09:00" required>
                        </div>

                        {{--  end date   --}}

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.end"):</label>
                            <input type="time" class="form-control" name="end" min="9:00" max="18:00" value="15:00"required>
                        </div>

                        {{--  address   --}}

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.address"):</label>
                            <input id="pac-input" type="text" class="form-control" name="address" required>
                        </div>
                        {{--  lag  , long   --}}

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.address"):</label>
                            <input id="latitude" class="form-control" type="text" name="lat" placeholder="Enter a location" value="29.979312">
                        </div>

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.address"):</label>
                            <input id="longitude" class="form-control" type="text" name="long" placeholder="Enter a location" value="31.2356913">
                        </div>

                        

                        {{--  <!-- new location lat ,lng -->  --}}
                        <!-- map -->
                        <div class="map">
                            <div class="row">
                                <div class="pac-card d-none" id="pac-card">
                                    <div>
                                        <div id="title">
                                            Autocomplete search
                                        </div>
                                        <div id="type-selector" class="pac-controls " >
                                            <input type="radio" name="type" id="changetype-all" checked="checked">
                                            <label for="changetype-all">All</label>

                                            <input type="radio" name="type" id="changetype-establishment">
                                            <label for="changetype-establishment">Establishments</label>

                                            <input type="radio" name="type" id="changetype-address">
                                            <label for="changetype-address">Addresses</label>

                                            <input type="radio" name="type" id="changetype-geocode">
                                            <label for="changetype-geocode">Geocodes</label>
                                        </div>
                                        <div id="strict-bounds-selector" class="pac-controls">
                                            <input type="checkbox" id="use-strict-bounds" value="">
                                            <label for="use-strict-bounds">Strict Bounds</label>
                                        </div>
                                    </div>
                                    <div id="pac-container">
                                        <input  type="text" placeholder="Enter a location">
                                    </div>
                                </div>
                                <div id="map" style="position: static !important"></div>
                                <div id="infowindow-content">
                                    <img src="" width="16" height="16" id="place-icon">
                                    <span id="place-name"  class="title"></span><br>
                                    <span id="place-address"></span>
                                </div>
 
                            </div>
                            <!-- map -->
                         </div>
                        <button type="submit" class="btn btn-primary">@lang('site.save')</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

      

@endsection
@section('script')
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDQiN4qc7pC9b1BRQwkqXXD28peMfWcHvw&libraries=places&callback=initMap&input=Egypt&language=ar"
async defer></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="{{ asset('app/map.js') }}"></script>

@endsection
