@extends('../layouts.app')

@section('content')
<style>
    body{
        direction: rtl;
        text-align: right;
    }
    .card-header {
        position: relative;
    }
    .plus
    {
        position: absolute;
        left: 0;
        top: 0px;
        margin: 10px;
        color: #fff;
        font-size: 10px;
    }
    .bg-info {
        background-color: #27ae60!important;
    }
    .card-body{
        padding: 0;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card">
                
                {{--  <a href="{{ url()->previous() }}">111</a>  --}}
                <div class="card-header bg-info text-white">@lang("site.client")
                    <a href="{{ url("delempoloye") }}" class="plus btn btn-danger btn-sm"> @lang("site.neworder") <i class="fa fa-trash"></i></a>
                </div>
                
                <div class="card-body">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">@lang("site.service")</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">@lang("site.terller")</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <table class="table table-responsive-xs table-bordered text-center">
                                    <thead>
                                        <tr class="">
                                            <th>@lang("site.id")</th>
                                            <th>@lang("site.name")</th> 
                                            <th>@lang("site.name braunch")</th> 
                                            <th>@lang("site.time")</th>
                                        </tr> 
                                    </thead> 
                                    <tbody>
                                        @foreach ($services as $service)
                                        <tr>
                                            <th scope="row">{{ $service->id }}</th>
                                            <td>{{$service->order->user->name }}</td>
                                            <td>{{$service->order->user->branche->name  }}</td>
                                            <td>{{$service->data_come }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                    <table class="table table-responsive-xs table-bordered text-center">
                                        <thead>
                                            <tr class="">
                                                <th>@lang("site.id")</th>
                                                <th>@lang("site.name")</th> 
                                                <th>@lang("site.name braunch")</th> 
                                                <th>@lang("site.time")</th>
                                            </tr> 
                                        </thead> 
                                        <tbody>
                                            @foreach ($terllers as $service)
                                            <tr>
                                                <th scope="row">{{ $service->id }}</th>
                                                <td>{{$service->order->user->name }}</td>
                                                <td>{{$service->order->user->branche->name  }}</td>
                                                <td>{{$service->data_come }}</td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

      

@endsection

