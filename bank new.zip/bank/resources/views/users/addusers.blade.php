@extends('../layouts.app')

@section('content')
<style>
    body{
        direction: rtl;
        text-align: right;
    }
    .card-header {
        position: relative;
    }
    .plus
    {
        position: absolute;
        left: 0;
        top: 0px;
        margin: 10px;
        color: #fff;
        font-size: 10px;
    }
    .bg-info {
        background-color: #27ae60!important;
    }
    .card-body{
        padding: 0;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card">
                {{--  <a href="{{ url()->previous() }}">111</a>  --}}
                <div class="card-header bg-info text-white">@lang("site.users")
                    <a href="{{ url()->previous() }}" class="plus btn btn-dark btn-sm"> @lang("site.perv") <i class="fa fa-arrow-left"></i></a>
                </div>
                
                <div class="card-body">
                    <form method="POST" action="{{ Route('users.store')}}" style="padding: 15px;">
                        @csrf
                        {{--  {{ method_field('PATCH') }}  --}}

                        {{--  username  --}} 
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.username") :</label>
                            <input type="text" class="form-control {{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" required value="{{ old("name") }}">
                            @if ($errors->has('name'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('name') }}</strong>
                                </span>
                            @endif
                           
                        </div>
    
                        {{--  email  --}}
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.email"):</label>
                            <input type="email" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" required value="{{ old("email") }}">
                            @if ($errors->has('email'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('email') }}</strong>
                                </span>
                            @endif
                           
                        </div>
    
                        {{--  password  --}}
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.password"):</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
    
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.role"):</label>
                            <select class=" edituser" style="width: 100%" name="role" required>
                                <option value="0" {{ old("role") == 1 ? "selected":"" }}>@lang("site.client")</option>
                                <option value="1" {{ old("role") == 1 ? "selected" : "" }}>@lang("site.admin")</option>
                                <option value="2" {{ old("role") == 2 ? "selected" : "" }}>@lang("site.emp")</option>

                            </select>
                        </div>

                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">@lang("site.chose brunch"):</label>
                            @if (count($branches) > 0)
                            <select class="edituser" style="width: 100%" name="Branche" required>
                              @foreach ( $branches as $branche)
                                <option value="{{ $branche->id}}">{{ $branche->name}}</option>
                              @endforeach
                            </select>
                            @endif
                        </div>

                        <button type="submit" class="btn btn-primary">@lang('site.save')</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

      

@endsection

