@extends('../layouts.app')

@section('content')
<style>
    body{
        direction: rtl;
        text-align: right;
    }
    .card-header {
        position: relative;
    }
    .plus
    {
        position: absolute;
        left: 0;
        top: 0px;
        margin: 10px;
        color: #fff;
        font-size: 10px;
    }
    .bg-info {
        background-color: #27ae60!important;
    }
    .card-body{
        padding: 0;
    }
    .table {
        margin-bottom: 0;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
                <div class="card-header bg-info text-white">@lang("site.users")
                    <a href="{{ route("users.create") }}"class="plus btn btn-dark btn-sm" >
                            <i class="fa fa-plus"></i> @lang("site.add")
                        </a>
                </div>
                
                <div class="card-body">
                    <div class="">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                    <table class="table table-responsive-xs table-bordered text-center">
                        <thead>
                            <tr class="">
                                <th>@lang("site.id")</th>
                                <th>@lang("site.name")</th> 
                                <th>@lang("site.stutas")</th> 
                                <th>@lang("site.options")</th>
                            </tr> 
                        </thead> 
                        <tbody>
                            @foreach ($users as $user)
                            <tr>
                                <th scope="row">{{ $user->id }}</th>
                                <td>{{ $user->name }}</td>
                                <td>
                                    @if ($user->role == 1 )
                                    <span class="badge badge-pill badge-primary text-white">@lang("site.admin")</span>
                                    @elseif ($user->role == 2 )
                                    <span class="badge badge-pill badge-danger text-white">@lang("site.emp")</span>
                                    @else
                                    <span class="badge badge-pill badge-dark text-white">@lang("site.client")</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="option">
                                        <a class="badge badge-success text-white" href="{{ Route("users.edit" ,$user->id  )}}"><i class="fa fa-edit"></i></a>                                    
                                        <form style="display: inline" action="{{ Route('users.destroy' , $user->id)}}" method="POST" >
                                            @csrf
                                            <input name="_method" type="hidden" value="DELETE">
                                            <button type="submit" style=" border: none;" class="badge badge-danger text-white" onclick="return confirm('Are you sure you want to delete this item?');">
                                                <i class="fa fa-trash"></i>
                                            </button>                                            
                                        </form>
                                    </div>
                                   
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

      
@endsection
