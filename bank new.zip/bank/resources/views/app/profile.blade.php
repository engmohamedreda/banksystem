<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="{{ asset('app/style.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('app/select2.min.css') }}" rel="stylesheet" type="text/css">    
    <link href="{{ asset('app/select2.full.min.js') }}" rel="stylesheet" type="text/css"> 

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDQiN4qc7pC9b1BRQwkqXXD28peMfWcHvw&libraries=places&callback=initMap&input=Egypt&language=ar"
    async defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="{{ asset('app/map.js') }}"></script>

    <style>
      label.btn span {
        font-size: 1.5em ;
      }

      label input[type="radio"] ~ i.fa.fa-circle-o{
          color: #c8c8c8;    display: inline;
      }
      label input[type="radio"] ~ i.fa.fa-dot-circle-o{
          display: none;
      }
      label input[type="radio"]:checked ~ i.fa.fa-circle-o{
          display: none;
      }
      label input[type="radio"]:checked ~ i.fa.fa-dot-circle-o{
          color: #7AA3CC;    display: inline;
      }
      label:hover input[type="radio"] ~ i.fa {
      color: #7AA3CC;
      }

      label input[type="checkbox"] ~ i.fa.fa-square-o{
          color: #c8c8c8;    display: inline;
      }
      label input[type="checkbox"] ~ i.fa.fa-check-square-o{
          display: none;
      }
      label input[type="checkbox"]:checked ~ i.fa.fa-square-o{
          display: none;
      }
      label input[type="checkbox"]:checked ~ i.fa.fa-check-square-o{
          color: #7AA3CC;    display: inline;
      }
      label:hover input[type="checkbox"] ~ i.fa {
      color: #7AA3CC;
      }

      div[data-toggle="buttons"] label.active{
          color: #7AA3CC;
      }

      div[data-toggle="buttons"] label {
        display: inline-block;
        padding: 6px 12px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 2em;
        text-align: left;
        white-space: nowrap;
        vertical-align: top;
        cursor: pointer;
        background-color: none;
        border: 0px solid 
        #c8c8c8;
        border-radius: 3px;
        color: #c8c8c8;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        -o-user-select: none;
        user-select: none;
      }

      div[data-toggle="buttons"] label:hover {
        color: #7AA3CC;
      }

      div[data-toggle="buttons"] label:active, div[data-toggle="buttons"] label.active {
        -webkit-box-shadow: none;
        box-shadow: none;
      }
          body{
              direction: rtl;
              text-align: right;
          }
          .card-header {
              position: relative;
          }
          .plus
          {
              position: absolute;
              left: 0;
              top: 0px;
              margin: 10px;
              color: #fff;
              font-size: 10px;
          }
          .bg-info {
              background-color: #27ae60!important;
          }
          .card-body{
              padding: 0;
          }
          #map {
        overflow: hidden;
        width: 100% !important;
        height: 320px !important;
        margin: 20px;
      }
      #description {
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
      }
      
      #infowindow-content .title {
        font-weight: bold;
      }
      
      #infowindow-content {
        display: none;
      }
      
      #map #infowindow-content {
        display: inline;
      }
      
      .pac-card {
        margin: 10px 10px 0 0;
        border-radius: 2px 0 0 2px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        outline: none;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        background-color: #fff;
        font-family: Roboto;
      }
      
      #pac-container {
        padding-bottom: 12px;
        margin-right: 12px;
      }
      
      .pac-controls {
        display: inline-block;
        padding: 5px 11px;
      }
      
      .pac-controls label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }
      
      #pac-input {
        background-color: #fff;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        margin-left: 12px;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        {{--  width: 400px;  --}}
      }
      
      #pac-input:focus {
        border-color: #4d90fe;
      }
      
      #title {
        color: #fff;
        background-color: #4d90fe;
        font-size: 25px;
        font-weight: 500;
        padding: 6px 12px;
      }
      
      </style>
  
    <title>Hello, world!</title>
  </head>
  <body>
      <!-- multistep form -->
      <div id="msform">
          <div class="panel panel-default">
              <div class="panel-heading">
                  <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">@lang('site.terller')</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">@lang('site.service')</a>
                    </li>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" >
                        @csrf
                        <button class="btn btn-danger" type="submit"><i class="fa fa-logout"></i> logout</button>
                      {{--  <b type="submit" name="" id="">  --}}
                    </form>

                    {{--  <a href="{{ route('logout')}}"></a>  --}}
                  </ul>
              </div>
              <div class="panel-body">


                  <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                      <a href="#" class="badge badge-success" style="color: #fff;background-color: #28a745;width: 150px;height: 200px;line-height: 60px;font-size: 30px;margin-top: 20px;margin-bottom: 20px;">
                          @if( $terller != null  ) {{ $terller->id }} <br> {{ Auth::user()->name }}  @endif <br > @if( $terller != null ) {{ $terller->data_come }} @endif
                      </a>
                      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">@lang('site.address')</button>
                   
                    </div>
                    {{--  end  --}}
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                      <a href="#" class="badge badge-success" style="color: #fff;background-color: #28a745;width: 150px;height: 200px;line-height: 60px;font-size: 30px;margin-top: 20px;margin-bottom: 20px;">
                        @if( $customer != null ) {{ $customer->id }} <br> {{ Auth::user()->name }} @endif <br > @if( $customer != null ) {{ $customer->data_come }} @endif

                        </a>
                      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">@lang('site.address')</button>
                      </div>
                      
                  </div>                    
              </div>
          </div>
        
        </div>
        
    <!-- Optional JavaScript -->

    <!-- Button trigger modal -->


    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">@lang("site.address")</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            {{--  strat  --}}
            <!-- map -->
            <div class="map">
                <div class="row">
                    <div class="pac-card d-none" id="pac-card">
                        <div>
                            <div id="title">
                                Autocomplete search
                            </div>
                            <div id="type-selector" class="pac-controls " >
                                <input type="radio" name="type" id="changetype-all" checked="checked">
                                <label for="changetype-all">All</label>
    
                                <input type="radio" name="type" id="changetype-establishment">
                                <label for="changetype-establishment">Establishments</label>
    
                                <input type="radio" name="type" id="changetype-address">
                                <label for="changetype-address">Addresses</label>
    
                                <input type="radio" name="type" id="changetype-geocode">
                                <label for="changetype-geocode">Geocodes</label>
                            </div>
                            <div id="strict-bounds-selector" class="pac-controls">
                                <input type="checkbox" id="use-strict-bounds" value="">
                                <label for="use-strict-bounds">Strict Bounds</label>
                            </div>
                        </div>
                        <div id="pac-container">
                            <input  type="text" placeholder="Enter a location">
                        </div>
                    </div>
                    <div id="map" style="position: static !important"></div>
                    <div id="infowindow-content">
                        <img src="" width="16" height="16" id="place-icon">
                        <span id="place-name"  class="title"></span><br>
                        <span id="place-address"></span>
                    </div>
    
                    <div class="form-group">
                        <input id="latitude" class="form-control" type="hidden" name="lat" placeholder="Enter a location" value="@if( $customer != null )  {{ $customer->lat}}  @elseif( $terller != null ) {{ $terller->lat}}   @endif">
                    </div>
    
                    <div class="form-group">
                        <input id="longitude" class="form-control" type="hidden" name="long" placeholder="Enter a location" value="@if( $customer != null ) {{ $customer->long}} @elseif($terller != null ) {{ $terller->long}} @endif">
                    </div>
                    
                </div>
                <!-- map -->
          </div>

        </div>
      </div>
    </div>




    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="{{ asset('app/select2.min.js') }}" ></script>
    <script src="{{ asset('app/main.js') }}" ></script>

  </body>
</html>

