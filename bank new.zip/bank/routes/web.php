<?php


Route::group(['middleware' => 'auth'], function (){
    Route::get('/', function () {
        if (Auth::user()->role == 0) {
            return redirect('request');
        } elseif (Auth::user()->role == 2){
            return redirect('empoloye');
        } else {
            return redirect('users');        
        }
        
    });
    
    

    Route::get('/hh', function () {
        return view('app.page');
    });
    
    Route::resource('users', 'AppController');
    Route::resource('branches', 'BrancheController');
    Route::get('request', 'AppController@request');
    Route::post('addrequest', 'OrdersController@store');
    Route::get("empoloye",'AppController@empoloye');
    Route::get("delempoloye",'OrdersController@destroy');

    Route::get("show_number",'OrdersController@show');
    
    // Route::get('test', function () {
    //     dd(\App\Order::find(8)->branche->lat);

    // });
    
});
Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

